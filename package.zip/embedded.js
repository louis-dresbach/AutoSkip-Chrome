// Runs in the tab with the player


const interval = 500;

let aS = false;
let sI = false;
let sO = false;

chrome.storage.sync.get("autoStart", ({ autoStart }) => {
	aS = autoStart;
});
chrome.storage.sync.get("skipIntro", ({ skipIntro }) => {
  sI = skipIntro;
});
chrome.storage.sync.get("skipOutro", ({ skipOutro }) => {
  sO = skipOutro;
});

const d = document.createElement("div");
const si = document.createElement("div");

const parseTime = (input) => {
	let ret = 0;
	let s = input.split(":");
	if(s.length == 3) {
		ret += parseInt(s[0]) * 60;
		ret += parseInt(s[1]) * 60;
		ret += parseInt(s[2]);
	}
	else if(s.length == 2) {
		ret += parseInt(s[0]) * 60;
		ret += parseInt(s[1]);
	}
	return ret;
};

const nextEp = () => {
	chrome.runtime.sendMessage({closeTab: true});
}

const skipIntro = () => {

}
	
// get intro, outro length from database
const introLength = parseTime("2:00");
const outroLength = parseTime("1:50");


const checkTime = () => {
	let timeElapsed, timeCountDown, timeDuration;

	const te = document.querySelector(".jw-text-elapsed");
	const tc = document.querySelector(".jw-text-countdown");
	const td = document.querySelector(".jw-text-duration");

	if (te && tc && td) {
		timeElapsed = parseTime(te.innerHTML);
		timeCountDown = parseTime(tc.innerHTML);
		timeDuration = parseTime(td.innerHTML);
		// skip intro
		if (timeElapsed < introLength) {
			if (sI) {
				skipIntro();
			}
			else {
				//si.style.display = "block";
			}
		}
		else {
			si.style.display = "none";
		}

		// next episode button
		if (outroLength > timeCountDown && timeElapsed > 30) {
			if (sO) {
				nextEp();
			}
			else {
				d.style.display = "block";
			}
		}
		else {
			d.style.display = "none";
		}
	}
};

const autoplay = () => {
	const p = document.querySelector('*[aria-label="Play"]');
	if(p)
		p.click();
}

window.onload = function () {
	// auto-click to start
	if(aS === true) {
		setTimeout(autoplay, 3000);
	}
	
	d.style.display = "none";
	d.className += "button";
	d.innerHTML = "► Next episode";
	d.addEventListener("click", () => { nextEp(); });
	document.body.appendChild(d);
	
	si.style.display = "none";
	si.className += "button";
	si.innerHTML = "Skip Intro";
	si.addEventListener("click", () => { skipIntro(); });
	document.body.appendChild(si);
	
	setInterval(checkTime, interval);
}